﻿//using System;

namespace LookupRDAP.Models
{
    public class RDAP
    {
        public class Globals
        {
            public static string RDAPIPPostURL = "https://rdap.db.ripe.net/ip";
            public static string RDAPDomainPostURL = "https://rdap.verisign.com/com/v1/domain";
        }
    }
}
