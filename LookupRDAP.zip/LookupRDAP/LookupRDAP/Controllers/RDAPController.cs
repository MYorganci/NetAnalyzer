﻿using System;
using System.Net.Http;
using System.Net.Http.Headers;
using Microsoft.AspNetCore.Mvc;
using LookupRDAP.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace LookupRDAP.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RDAPController : ControllerBase
    {

        // GET api/<LookupRDAPController>/5
        [HttpGet("{ipDomain} {IsIP}")]
        public string Get(string ipDomain, string IsIP)
        {
            string postURL = "";
            if (ipDomain == "")
            {
                return "No domain or IP information provided";
            }
            // sort out the kink in this particular service
            ipDomain = ipDomain.Replace("https://www.", "");
            ipDomain = ipDomain.Replace("http://www.", "");
            ipDomain = ipDomain.Replace("www.", "");
            if (IsIP.ToUpper() == "TRUE")
            {
                postURL = RDAP.Globals.RDAPIPPostURL + "/" + ipDomain;
            } 
            else { 
                postURL = RDAP.Globals.RDAPDomainPostURL + "/" + ipDomain;
            }
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(postURL);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            var json = client.GetStringAsync(postURL).Result;
            return json.ToString();
        }

    }
}
