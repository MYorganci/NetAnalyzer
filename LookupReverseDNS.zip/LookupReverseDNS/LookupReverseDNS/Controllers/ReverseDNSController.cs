﻿
using Microsoft.AspNetCore.Mvc;
using System;
using System.Net.Http;
using System.Net.Http.Headers;
using LookupReverseDNS.Models;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace LookupReverseDNS.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReverseDNSController : ControllerBase
    {

        // GET api/<ReverseDNSController>/5
        [HttpGet("{IP}")]
        public string Get(string IP)
        {
            if (IP == "")
            {
                return "No IP information provided";
            }
            string postURL = ReverseDNS.Globals.postURL1 + IP + ReverseDNS.Globals.postURL2;
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(postURL);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            var json = client.GetStringAsync(postURL).Result;
            return json.ToString();
        }
    }
}
