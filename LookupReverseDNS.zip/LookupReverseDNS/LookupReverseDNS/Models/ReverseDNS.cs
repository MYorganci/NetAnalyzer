﻿
namespace LookupReverseDNS.Models
{
    public class ReverseDNS
    {
        public class Globals
        {
            public static string postURL1 = "https://api.viewdns.info/reversedns/?ip=";
            public static string postURL2 = "&apikey=0381c2f8ce83392af5ca4e950368b75faf03c0ad&output=json";
        }
    }

}
