﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using Microsoft.AspNetCore.Mvc;
using NetAnalyzer.Models;
using System.Threading.Tasks;
// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace NetAnalyzer.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class NetAnalyzer : ControllerBase
    {

        // GET: api/<NetAnalyzer>
        [HttpGet]
        public IEnumerable<string> Get()
        {
            // return the currently available, valid service names
            return Globals.defServices;
        }

        // GET: api/<NetAnalyzer>/sampleio
        [HttpGet("{sampleIO}")]
        public string Get(string sampleIO)
        {
            string returnStr = "";
            if(sampleIO.ToUpper() == "SAMPLEINPUT")
            {
                returnStr = "{ \"netServices\": [  {  \"name\": \"Ping\"  },  { \"name\": \"ReverseDNS\" }  ]  }";
            }
            if (sampleIO.ToUpper() == "SAMPLEOUTPUT")
            {
                returnStr = "{ \"GeoIP\":  \"\" , \"Ping\":  { \"Target\": \"159.255.xxx.xxx\", \"Status\": \"Success\", \"ResponseDelay - ms\": 34 } ,  \"RDAP\":  \"\" ,  \"ReverseDNS\":  {\"query\" : {\"tool\" : \"reversedns_PRO\",\"ip\" : \"159.255.xxx.xxx\"},\"response\" : {\"rdns\" : \"3(NXDOMAIN)\"}} ,  \"VirusTotal\":  \"\"  }";
            }
            else {
                returnStr = "{ \"netServices\": [  {  \"name\": \"Ping\"  },  { \"name\": \"ReverseDNS\" }  ]  }";
            }

            return returnStr;
        }

            // PUT api/<NetAnalyzer>/5
            [HttpPut("{domainIP}")]
        // The PUT call allows passing Json record for optional input parameters.
        // The alternative was to concatenate all options into the postURL which would not be pretty or practical to work with.
        public string  Put(string domainIP, [FromBody] inputServiceNames value)
            {
            int returnCount = 0;
            int validInputSvcCount = 0;
            int i;

            GlobalsVars GV = new GlobalsVars();
            domainIP = domainIP.Trim();

            #region Validations
            if (domainIP.Trim() == "")
            {
                return GV.retEmptyJson;
            }

            IPAddress ip;
            bool ValidatedIP = IPAddress.TryParse(domainIP, out ip);
            // if not a valid IP, is it a valid domain name?
            if( ! ValidatedIP)
            {
                if (!NetAnalyzer.IsValidDomainName(domainIP))
                {
                    return GV.retErrorJson.Replace("{ErrorInfo}", "Invalid IP Address, or domain name: " + domainIP);
                }
            }
            #endregion

            #region setDefaults
            if (value.netServices == null || value.netServices.Count == 0)
            {
                // go with default set of service names which are:
                // GeoIP and Ping services.
                #region set the default services
                    netService srvObj = new netService();
                    srvObj.name = "GeoIP";  srvObj.valid = 999;
                    value.netServices = new List<netService>();
                    value.netServices.Add(srvObj);
                    srvObj = new netService();
                    srvObj.name = "Ping"; srvObj.valid = 999;
                    value.netServices.Add(srvObj);
                    validInputSvcCount = value.netServices.Count;
                #endregion
            }
                else {
                // Validate the input service names against the known list of valid services and mark the valid ones.

                    foreach (netService item in value.netServices)
                    {
                        for (i = 0; i < Globals.defServices.Length; i++)
                        {
                            if (Globals.defServices[i].ToUpper() == item.name.ToUpper())
                            {
                                item.valid = 999;
                            }
                        }
                    }
                // Now, we can set the number of valid service names input to the system
                validInputSvcCount = value.netServices.Count;
                foreach (netService item in value.netServices)
                {
                    if (item.valid != 999)
                    {
                        validInputSvcCount--;
                    }
                }
            }
            // If no valid service name is provided, stop here.
            if (validInputSvcCount < 1) { 
                 GV.retMainJson = GV.retErrorJson.Replace("{ErrorInfo}", "No valid service name provided.");
                return GV.retMainJson;
            }
            #endregion

            string postURL = "";
            foreach (netService item in value.netServices)
            {
                if(item.valid != 999)
                {
                    break;
                }
                if (item.name.ToUpper() == "GEOIP")
                {
                    postURL = Globals.GeoIPPostURL + "/" + domainIP;
                    GV.GeoIPJson = GV.GeoIPJson.Replace("{GeoIP}", GetAsynchResults(postURL));
                    returnCount++;
                }
                if (item.name.ToUpper() == "RDAP")
                {
                    postURL = Globals.RDAPPostURL + "/" + domainIP + " " + ValidatedIP.ToString(); 
                    GV.RDAPJson = GV.RDAPJson.Replace("{RDAP}", GetAsynchResults(postURL));
                    returnCount++;
                }
                if (item.name.ToUpper() == "REVERSEDNS")
                // this lookup only applies for IP addresses, not DNS name inputs.
                {
                    if (ValidatedIP) {
                        postURL = Globals.ReverseDNSPostURL + "/" + domainIP; 
                        GV.ReverseDNSJson = GV.ReverseDNSJson.Replace("{ReverseDNS}", GetAsynchResults(postURL));
                        returnCount++;
                    } else
                    {
                        GV.ReverseDNSJson = GV.ReverseDNSJson.Replace("{ReverseDNS}", "\"A valid IP address is needed: " + domainIP + "\" ");
                        returnCount++;
                    }                
                }
                if (item.name.ToUpper() == "PING")
                {
                    postURL = Globals.PingPostURL + "/" + domainIP;
                    Task TRest = ProcessRestMethod(postURL);
                    var genericTask = TRest as Task<string>;
                    TRest.Wait();
                    System.Threading.Thread.Sleep(500);
                    if (TRest.IsCompleted)
                    {
                        GV.PingJson = GV.PingJson.Replace("{Ping}", genericTask.Result.ToString());
                    }
                    returnCount++;
                }
                if (item.name.ToUpper() == "VIRUSTOTAL")
                {
                    // this lookup only applies for domain addresses, not IP address inputs.
                    if (!ValidatedIP)
                    {
                        postURL = Globals.VirusTotalPostURL + "/" + domainIP;
                        Task TRest = ProcessRestMethod(postURL);
                        var genericTask = TRest as Task<string>;                    
                        TRest.Wait();

                        if (TRest.IsCompleted) {
                            System.Threading.Thread.Sleep(500);
                            GV.VirusTotalJson = GV.VirusTotalJson.Replace("{VirusTotal}", genericTask.Result.ToString());
                        }
                        returnCount++;
                    }
                    else
                    {
                        GV.VirusTotalJson = GV.VirusTotalJson.Replace("{VirusTotal}", "\"A valid domain address is needed: " + domainIP + "\" ");
                        returnCount++;
                    }
                }
            }
            // Wait a bit for processes to return values. Sleep time to be propotional to number of lookups. Could be further improved if individualized per process type
        
            
        
           if (returnCount > 0)
                {
                    GV.retMainJson = "{ ";
                    GV.retMainJson = GV.retMainJson + GV.GeoIPJson.Replace("{GeoIP}", "\"\"") + ", " + GV.PingJson.Replace("{Ping}", "\"\"") + ", " + GV.RDAPJson.Replace("{RDAP}", "\"\"") + ", " + GV.ReverseDNSJson.Replace("{ReverseDNS}", "\"\"") + ", " + GV.VirusTotalJson.Replace("{VirusTotal}", "\"\"");
                    GV.retMainJson = GV.retMainJson + " }";
            }
           else
            {
                return GV.retEmptyJson;
            }

            return GV.retMainJson ;
        }
        private static string GetAsynchResults(string postURL)
        {
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(postURL);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            //   var json = client.GetStringAsync(postURL).Result;
            var json = client.GetStringAsync(postURL).Result;
            var json_data = JsonConvert.DeserializeObject(json);

            return json_data.ToString();
        }
        private async Task<string> ProcessRestMethod(string postURL)
        {
            string result = "";
            using (HttpClient httpClient = new HttpClient())
            {
                httpClient.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

                result = await httpClient.GetStringAsync(postURL);

            }
            if (result == "")
                result = "{\"status\":{\"code\":1000,\"message\":\"Unkown Error Ocured\"}}";
            var json_data = JsonConvert.DeserializeObject(result);
            
            return json_data.ToString();
        }
        private static bool IsValidDomainName(string domain)
        {
            if (String.IsNullOrEmpty(domain) || domain.Length > 255)
            {
                return false;
            }

            Uri uri;

            if (!Uri.TryCreate("http://" + domain, UriKind.Absolute, out uri))
            {
                return false;
            }

            if (!String.Equals(uri.Host, domain, StringComparison.OrdinalIgnoreCase) || !uri.IsWellFormedOriginalString())
            {
                return false;
            }

            foreach (string part in uri.Host.Split('.'))
            {
                if (part.Length > 63)
                {
                    return false;
                }
            }

            // if the last character in the domain name is a period, it is invalid.
            if(domain.Substring(domain.Length -1, 1) == ".")
            {
                return false;
            }
            return true;
        }
    }
}
