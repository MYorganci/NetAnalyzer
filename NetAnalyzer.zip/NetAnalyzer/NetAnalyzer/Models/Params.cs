﻿
using System.Collections.Generic;

namespace NetAnalyzer.Models
{
    public class Globals
    {
        // Must update the worker processes' URLs per respective URLs they are deployed to in your configuration.

        // LOCAL Mode
        //public static string GeoIPPostURL = "https://localhost:44360/api/geoipinfo";
        //public static string RDAPPostURL = "https://localhost:44389/api/RDAP";
        //public static string ReverseDNSPostURL = "https://localhost:44374/api/ReverseDNS";
        //public static string PingPostURL = "https://localhost:44356/api/ping";
        //public static string VirusTotalPostURL = "https://localhost:44343/api/virustotal";

        // Deployed to SERVER  Mode
        public static string GeoIPPostURL = "http://159.255.42.8:603/api/geoipinfo";
        public static string RDAPPostURL = "http://159.255.42.8:604/api/RDAP";
        public static string ReverseDNSPostURL = "http://159.255.42.8:605/api/ReverseDNS";
        public static string PingPostURL = "http://159.255.42.8:602/api/ping";
        public static string VirusTotalPostURL = "http://159.255.42.8:606/api/virustotal";
        public static string[] defServices = { "GeoIP", "RDAP", "ReverseDNS", "Ping", "VirusTotal" };
    }
    public class GlobalsVars { 
        public string retEmptyJson = "{ }";
        public string retErrorJson = "{ \"Error\":   \"{ErrorInfo} \"  }";
        public string GeoIPJson = "  \"GeoIP\":  {GeoIP} ";
        public string RDAPJson = "  \"RDAP\":  {RDAP} ";
        public string ReverseDNSJson = "  \"ReverseDNS\":  {ReverseDNS} ";
        public string PingJson = "  \"Ping\":  {Ping} ";
        public string VirusTotalJson = "  \"VirusTotal\":  {VirusTotal} ";
        public string retMainJson = "";
    }
  
    public class netService
    {
        public string name { get; set; }
        public int valid { get; set; }
    }
    public class inputServiceNames
    {
       // public string domainIP { get; set; }
        public List<netService> netServices { get; set; }
    }
  
}
