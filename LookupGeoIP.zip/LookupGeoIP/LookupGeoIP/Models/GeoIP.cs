﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace LookupGeoIP.Models
{
    public class GeoIP
    {
        public class Globals
        {
            public static string postURL1 = "http://api.ipstack.com/";
            public static string postURL2 = "?access_key=eafa84955b5b6b2bcc8933fbe807f19c";
        }
    }
}
