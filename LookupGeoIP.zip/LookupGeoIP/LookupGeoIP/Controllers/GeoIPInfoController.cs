﻿using System;
using System.Net.Http;
using System.Net.Http.Headers;
using LookupGeoIP.Models;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace LookupGeoIP.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GeoIPInfoController : ControllerBase
    {
       
        // GET api/<GeoIPInfoController>/5
        [HttpGet("{ipDomain}")]
        public string Get(string ipDomain)
        {
            if(ipDomain == "")
            {
                return "No domain or IP information provided";
            }
            string postURL = GeoIP.Globals.postURL1 + ipDomain + GeoIP.Globals.postURL2;
            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(postURL);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            var json = client.GetStringAsync(postURL).Result;
            return json.ToString();
        } 
    }
}
