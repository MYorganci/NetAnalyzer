﻿using System;
using System.Collections.Generic;
using LookupVirusTotal.Models;
using System.Threading.Tasks;
using System.Net.Http;
using System.Net.Http.Headers;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace LookupVirusTotal.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VirusTotalController : ControllerBase
    {
    

        // GET api/<VirusTotalController>/5
        [HttpGet("{ipDomain}")]
        public string Get(string ipDomain)
        {
            string postURL = VirusTotal.Globals.postURL + "/" +  ipDomain;
            string apiKey = VirusTotal.Globals.apiKey;

            HttpClient client = new HttpClient();
            client.BaseAddress = new Uri(postURL);
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
            client.DefaultRequestHeaders.Add("X-Apikey", apiKey);
            var json = client.GetStringAsync(postURL).Result;

            return json.ToString();
        }

       
    }
}
