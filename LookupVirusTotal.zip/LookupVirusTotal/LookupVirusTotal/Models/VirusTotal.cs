﻿
namespace LookupVirusTotal.Models
{
    public class VirusTotal
    {
        public class Globals
        {
            public static string postURL = "https://www.virustotal.com/api/v3/domains";
            public static string apiKey = "59afe54aa3e3e95dd8ef1aa5993c739e4f0e183ab819c9e116441f22a4df68bd";
        }
    }
}
