﻿using System;
using System.Net.NetworkInformation;
using Microsoft.AspNetCore.Mvc;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace LookupPing.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PingController : ControllerBase
    {

        // GET api/<PingController>/5
        [HttpGet("{ipDomain}")]
        public string Get(string ipDomain)
        {
            Ping p = new Ping();
            PingReply r;
            try
            {
                r = p.Send(ipDomain);

                string jsonLoad = "{ \"Target\": \"{Target}\", \"Status\": \"{Status}\", \"ResponseDelay-ms\": {ResponseDelay-ms} }";
                jsonLoad = jsonLoad.Replace("{Target}", ipDomain);
                if (r.Status == IPStatus.Success)
                {
                    jsonLoad = jsonLoad.Replace("{Status}", "Success");
                    jsonLoad = jsonLoad.Replace("{ResponseDelay-ms}", r.RoundtripTime.ToString());
                }
                else
                {
                    jsonLoad = jsonLoad.Replace("{Status}", "Failure");
                    jsonLoad = jsonLoad.Replace("{ResponseDelay-ms}", "");
                }
                return jsonLoad;
              
             }
            catch (Exception e)
            {
                string jsonLoad = "{ \"Target\": \"{Target}\", \"Status\": \"Exception\", \"ResponseDelay-ms\":  \"\" }".Replace("{Target}", ipDomain);
                return jsonLoad;
            }
        }
    }
}
